<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require "routes/dashboard.php";
require "routes/task.php";
require "routes/user.php";
require "routes/member.php";








